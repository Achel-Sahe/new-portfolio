import { useState } from "react";
import { ArrowDownRight, ArrowRight, ArrowUpRight, ChevronDown, Menu, X } from "lucide-react";

const links = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#intro" },
  { label: "Brands", href: "#partner-logos" },
  { label: "Careers", href: "mailto:hello@zenixa.studio?subject=Careers" },
  { label: "Partners", href: "#partner-logos" },
];

function BrandMark() {
  return (
    <svg aria-hidden="true" viewBox="0 0 28 28" className="h-[25px] w-[25px]">
      <path d="M5 5.5h12.5l5.5 5.4v11.6H5z" fill="currentColor" />
      <path d="M5 10.5h13M12.5 5.5v6M18 10.5v12" stroke="#eef0f1" strokeWidth="1.15" />
      <path d="m18.4 5.5 4.1 4.1" stroke="#eef0f1" strokeWidth="1.15" />
    </svg>
  );
}

function ArrowPill({ children, href, muted = false }: { children: React.ReactNode; href: string; muted?: boolean }) {
  return (
    <a
      href={href}
      className={`group inline-flex h-12 items-center gap-4 rounded-full pl-6 pr-2 text-[13px] font-medium tracking-[-0.01em] transition-all duration-200 active:scale-[.97] ${muted ? "border border-black/10 bg-white/45 text-[#383b3f] hover:bg-white/80" : "bg-[#17191b] text-white hover:bg-[#303337]"}`}
    >
      <span>{children}</span>
      <span className={`grid h-8 w-8 place-items-center rounded-full transition-transform duration-200 group-hover:translate-x-0.5 ${muted ? "bg-[#dfe1e2] text-[#232528]" : "bg-[#f0f1f2] text-[#17191b]"}`}>
        <ArrowUpRight size={14} strokeWidth={1.8} />
      </span>
    </a>
  );
}

export default function Home() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [productOpen, setProductOpen] = useState(false);

  return (
    <main id="home" className="hero-shell relative isolate min-h-[700px] overflow-hidden bg-[#eef0f1] text-[#17191b] sm:min-h-[760px]">
      <div className="grain-layer pointer-events-none absolute inset-0 z-0" />
      <header className="site-header relative z-40 mx-auto flex h-[76px] w-full max-w-[1600px] items-center justify-between px-5 sm:px-8 lg:px-12">
        <a href="#home" aria-label="Zenixa home" className="brand-lockup flex shrink-0 items-center gap-2.5">
          <BrandMark />
          <span className="text-[17px] font-semibold tracking-[-0.075em]">Zenixa</span>
        </a>

        <nav aria-label="Main navigation" className="hidden items-center gap-7 text-[11px] font-medium tracking-[-0.02em] text-[#515459] lg:flex">
          <a className="nav-link nav-current" href="#home">Home<span className="nav-dot" /></a>
          <div className="relative">
            <button type="button" onClick={() => setProductOpen((open) => !open)} className="nav-link inline-flex items-center gap-1" aria-expanded={productOpen}>
              Product <ChevronDown size={11} className={`transition-transform ${productOpen ? "rotate-180" : ""}`} />
            </button>
            {productOpen && (
              <div className="product-popover absolute left-1/2 top-8 z-50 w-48 -translate-x-1/2 rounded-2xl border border-black/[.07] bg-[#f8f9f9] p-2 shadow-[0_18px_50px_rgba(22,25,29,.14)]">
                <a href="#studio-card" onClick={() => setProductOpen(false)} className="block rounded-xl px-3 py-2.5 text-[11px] text-[#4d5054] transition-colors hover:bg-black/[.04]">Digital experiences</a>
                <a href="#intro" onClick={() => setProductOpen(false)} className="block rounded-xl px-3 py-2.5 text-[11px] text-[#4d5054] transition-colors hover:bg-black/[.04]">Brand direction</a>
              </div>
            )}
          </div>
          {links.slice(1).map((link) => <a key={link.label} href={link.href} className="nav-link">{link.label}</a>)}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <div className="date-chip flex h-[34px] items-center gap-2 rounded-lg border border-black/[.08] bg-white/35 px-3 text-[9px] text-[#65696e]">
            <span>Studio</span><span className="h-3 w-px bg-black/15" /><span className="font-medium text-[#313438]">52° 13′ N · 21° 00′ E</span>
          </div>
          <a href="mailto:hello@zenixa.studio" className="inline-flex h-[36px] items-center gap-2 rounded-lg border border-black/[.09] bg-white/30 px-3.5 text-[10px] font-medium transition-colors hover:bg-white/70">
            <span className="h-1.5 w-1.5 rounded-full bg-[#e9a46d]" /> Let&apos;s talk
          </a>
        </div>
        <button type="button" aria-label={mobileOpen ? "Close menu" : "Open menu"} aria-expanded={mobileOpen} onClick={() => setMobileOpen((open) => !open)} className="grid h-10 w-10 place-items-center rounded-full border border-black/10 bg-white/40 lg:hidden">
          {mobileOpen ? <X size={17} /> : <Menu size={17} />}
        </button>
      </header>

      {mobileOpen && (
        <nav aria-label="Mobile navigation" className="mobile-menu absolute left-4 right-4 top-[68px] z-50 grid gap-1 rounded-2xl border border-black/[.08] bg-[#f7f8f8]/95 p-3 shadow-xl backdrop-blur-xl lg:hidden">
          {[links[0], { label: "Product", href: "#studio-card" }, ...links.slice(1)].map((link) => (
            <a key={link.label} href={link.href} onClick={() => setMobileOpen(false)} className="rounded-xl px-4 py-3 text-sm text-[#42464a] hover:bg-black/[.04]">{link.label}</a>
          ))}
        </nav>
      )}

      <section id="intro" className="hero-stage relative z-10 mx-auto h-[calc(100svh-76px)] min-h-[624px] max-h-[960px] w-full max-w-[1600px] overflow-hidden px-5 sm:px-8 lg:px-12">
        <div className="hero-copy absolute left-5 top-[14%] z-20 w-[min(77vw,660px)] sm:left-8 sm:top-[16%] lg:left-12">
          <div className="eyebrow mb-5 flex items-center gap-2 text-[11px] font-medium tracking-[.015em] text-[#6d7278]">
            <span className="h-px w-5 bg-[#e19b6a]" /> Independent creative studio
          </div>
          <h1 className="hero-title max-w-[680px] text-[clamp(2.85rem,6.15vw,6rem)] font-medium leading-[.84] tracking-[-.085em] text-[#202225]">
            <span className="block">We start from</span>
            <span className="block">zero, delivering</span>
            <span className="block">only what matters.</span>
          </h1>
          <div className="mt-6 flex items-center gap-4 text-[10px] text-[#676b70] sm:mt-7">
            <div aria-label="Five out of five stars" className="flex items-center gap-[2px] text-[#d49168]">
              {[0, 1, 2, 3, 4].map((star) => <span key={star} className="text-[13px] leading-none">★</span>)}
            </div>
            <span className="h-3.5 w-px bg-black/15" />
            <span><strong className="font-semibold text-[#35383b]">300+</strong> customers</span>
          </div>
          <div className="mt-8 flex items-center gap-2.5 sm:mt-9">
            <ArrowPill href="mailto:hello@zenixa.studio?subject=Let%27s%20make%20something">Chat with us</ArrowPill>
            <ArrowPill href="#partner-logos" muted>Our work</ArrowPill>
          </div>
        </div>

        <div className="wordmark-backdrop pointer-events-none absolute bottom-[7%] left-1/2 z-[1] -translate-x-1/2 whitespace-nowrap text-[clamp(7rem,22vw,21rem)] font-semibold leading-[.7] tracking-[-.105em] text-white/55">ZENIXA</div>

        <div className="portrait-wrap pointer-events-none absolute inset-x-0 bottom-[-1px] z-10 flex h-[96%] items-end justify-center" aria-hidden="true">
          <img className="hero-portrait h-full w-auto max-w-none object-contain object-bottom" src="/manus-storage/zenixa-hero-bust-a_179b9c13.png" alt="" />
        </div>

        <aside id="studio-card" className="studio-card absolute right-5 top-[16%] z-20 hidden w-[min(31vw,355px)] overflow-hidden rounded-[21px] border border-white/75 bg-[#e4e6e8]/80 p-[7px] shadow-[0_14px_35px_rgba(41,46,52,.08)] backdrop-blur-md sm:block lg:right-12 lg:top-[17%]">
          <div className="flex items-stretch gap-4">
            <div className="studio-mark relative grid aspect-square w-[39%] shrink-0 place-items-center overflow-hidden rounded-[15px] bg-[#090a0c] text-white">
              <span className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_85%,rgba(255,255,255,.08),transparent_58%)]" />
              <svg aria-hidden="true" viewBox="0 0 42 42" className="relative h-8 w-8">
                <path d="M8 9h17l9 9v15H8z" fill="currentColor" />
                <path d="M8 17h17M17 9v9M25 17v16" stroke="#0b0c0e" strokeWidth="1.8" />
                <circle cx="31" cy="10" r="3" fill="#e6a077" />
              </svg>
            </div>
            <div className="flex min-w-0 flex-1 flex-col justify-between py-4 pr-3">
              <span className="self-end rounded-full border border-black/10 px-2 py-1 text-[8px] uppercase tracking-[.16em] text-[#72767a]">01 / 04</span>
              <div>
                <p className="text-[clamp(1rem,1.6vw,1.35rem)] font-medium leading-[1.1] tracking-[-.06em] text-[#51555a]">Design to<br />explore.</p>
                <div className="mt-4 flex items-center justify-between">
                  <span className="h-px w-10 bg-[#777c81]" />
                  <ArrowRight size={14} className="text-[#868a8e]" />
                </div>
              </div>
            </div>
          </div>
        </aside>

        <div id="partner-logos" className="partner-zone absolute right-6 top-[57%] z-20 hidden w-[min(31vw,350px)] text-[#555a5f] sm:block lg:right-12">
          <p className="mb-5 text-right text-[9px] font-medium tracking-[.02em] text-[#74797e]">Some of our partners</p>
          <div className="grid grid-cols-3 gap-x-5 gap-y-4 text-[11px] font-semibold tracking-[-.04em]">
            <span className="flex items-center gap-1.5"><span className="text-[15px]">✣</span> zantic</span>
            <span className="flex items-center gap-1.5 text-[#72777b]"><span className="text-[13px]">◫</span> blockton</span>
            <span className="flex items-center gap-1.5 text-[#74797e]"><span className="text-[12px]">✳</span> vager</span>
            <span className="flex items-center gap-1.5 text-[#74797e]"><span className="text-[12px]">◈</span> wexon</span>
            <span className="flex items-center gap-1.5 text-[#74797e]"><span className="text-[12px]">◌</span> cova</span>
            <span className="flex items-center gap-1.5 text-[#74797e]"><span className="text-[12px]">⌁</span> nerry</span>
          </div>
        </div>

        <div className="hero-side-note absolute bottom-[17%] left-5 z-20 hidden items-center gap-2 text-[9px] uppercase tracking-[.15em] text-[#74797d] sm:flex lg:left-12">
          <ArrowDownRight size={13} /> Scroll to explore
        </div>

        <div className="bottom-dock absolute bottom-4 left-4 right-4 z-30 grid h-[58px] grid-cols-3 items-center rounded-[14px] border border-white/15 bg-[#171a1d]/80 px-4 text-[9px] text-white/75 shadow-[0_20px_55px_rgba(15,17,20,.15)] backdrop-blur-xl sm:bottom-5 sm:left-8 sm:right-8 sm:h-[66px] sm:px-6 lg:left-12 lg:right-12">
          <span className="flex items-center gap-2"><span className="grid h-6 w-6 place-items-center rounded-full bg-white/10 text-[10px]">✳</span><span className="hidden sm:inline">Make room for the unexpected</span><span className="sm:hidden">Stay curious</span></span>
          <span className="dock-center justify-self-center border-x border-white/10 px-6 text-center text-white/90">✦ &nbsp; Based in Warsaw</span>
          <a href="#partner-logos" className="group flex items-center justify-self-end gap-2 transition-colors hover:text-white"><span className="hidden sm:inline">Scroll to discover</span><span className="sm:hidden">Explore</span><ArrowUpRight size={13} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></a>
        </div>
      </section>
    </main>
  );
}
